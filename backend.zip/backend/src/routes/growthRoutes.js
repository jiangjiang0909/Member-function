import express from 'express';
import { getGrowthRecords, addGrowthValue, deductGrowthValue, getLevelInfo } from '../controllers/growthController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', protect, getGrowthRecords);
router.post('/add', protect, addGrowthValue);
router.post('/deduct', protect, deductGrowthValue);
router.get('/level', protect, getLevelInfo);

export default router;

import express from 'express';
import { getTasks, getTaskById, createTask, updateTask, deleteTask, completeTask, getAllTasksForAdmin } from '../controllers/taskController.js';
import { protect } from '../middleware/authMiddleware.js';
import { adminOnly } from '../middleware/adminMiddleware.js';

const router = express.Router();

router.get('/', protect, getTasks);
router.get('/:id', protect, getTaskById);
router.post('/', protect, createTask);
router.put('/:id', protect, updateTask);
router.delete('/:id', protect, deleteTask);
router.post('/:id/complete', protect, completeTask);

router.get('/admin/list', protect, adminOnly, getAllTasksForAdmin);

export default router;

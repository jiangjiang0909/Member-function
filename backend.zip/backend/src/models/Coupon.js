import mongoose from 'mongoose';

const couponSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['discount', 'full', 'gift', 'activity'],
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  minAmount: {
    type: Number,
    default: 0
  },
  description: {
    type: String,
    default: ''
  },
  validStart: {
    type: Date,
    required: true
  },
  validEnd: {
    type: Date,
    required: true
  },
  minLevel: {
    type: String,
    enum: ['newbie', 'silver', 'gold', 'diamond'],
    default: 'newbie'
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('Coupon', couponSchema);

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema({
  phone: {
    type: String,
    required: true,
    unique: true,
    match: /^1[3-9]\d{9}$/
  },
  password: {
    type: String,
    required: true
  },
  nickname: {
    type: String,
    default: '丰速用户'
  },
  avatar: {
    type: String,
    default: ''
  },
  memberLevel: {
    type: String,
    enum: ['newbie', 'silver', 'gold', 'diamond'],
    default: 'newbie'
  },
  growthValue: {
    type: Number,
    default: 0
  },
  totalGrowthValue: {
    type: Number,
    default: 0
  },
  completedTasks: {
    type: [String],
    default: []
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastActive: {
    type: Date,
    default: Date.now
  }
});

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    next();
  }
  const salt = await bcrypt.genSalt(process.env.BCRYPT_ROUNDS);
  this.password = await bcrypt.hash(this.password, salt);
});

userSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

userSchema.methods.calculateLevel = function() {
  const growth = this.growthValue;
  if (growth >= 2000) return 'diamond';
  if (growth >= 500) return 'gold';
  if (growth >= 100) return 'silver';
  return 'newbie';
};

export default mongoose.model('User', userSchema);

import mongoose from 'mongoose';

const taskSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  category: {
    type: String,
    enum: ['newbie', 'daily', 'advanced', 'premium'],
    required: true
  },
  actionType: {
    type: String,
    enum: ['order', 'view', 'survey', 'amount'],
    default: 'order'
  },
  description: {
    type: String,
    default: ''
  },
  reward: {
    type: Number,
    required: true
  },
  cycleType: {
    type: String,
    enum: ['daily', 'monthly'],
    default: 'daily'
  },
  validityDays: {
    type: Number,
    default: 0
  },
  target: {
    type: Number,
    default: 1
  },
  targetAmount: {
    type: Number,
    default: 0
  },
  targetDuration: {
    type: Number,
    default: 0
  },
  targetPage: {
    type: String,
    default: ''
  },
  surveyUrl: {
    type: String,
    default: ''
  },
  minLevel: {
    type: String,
    enum: ['newbie', 'silver', 'gold', 'diamond'],
    default: 'newbie'
  },
  status: {
    type: String,
    enum: ['online', 'offline'],
    default: 'online'
  },
  completionCount: {
    type: Number,
    default: 0
  },
  conversionRate: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('Task', taskSchema);

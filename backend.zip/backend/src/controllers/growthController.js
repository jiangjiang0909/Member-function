import User from '../models/User.js';
import GrowthRecord from '../models/GrowthRecord.js';

export const getGrowthRecords = async (req, res) => {
  try {
    const { type } = req.query;
    let query = { userId: req.user._id };
    
    if (type && ['income', 'expense', 'expired'].includes(type)) {
      query.type = type;
    }
    
    const records = await GrowthRecord.find(query).sort({ createdAt: -1 });
    res.json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const addGrowthValue = async (req, res) => {
  try {
    const { amount, description, source } = req.body;
    
    const user = await User.findById(req.user._id);
    user.growthValue += amount;
    user.totalGrowthValue += amount;
    
    const newLevel = user.calculateLevel();
    if (newLevel !== user.memberLevel) {
      user.memberLevel = newLevel;
    }
    
    await user.save();
    
    await GrowthRecord.create({
      userId: user._id,
      type: 'income',
      amount,
      description,
      source
    });
    
    res.json({
      message: '成长值已添加',
      growthValue: user.growthValue,
      memberLevel: user.memberLevel
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const deductGrowthValue = async (req, res) => {
  try {
    const { amount, description, source } = req.body;
    
    const user = await User.findById(req.user._id);
    
    if (user.growthValue < amount) {
      return res.status(400).json({ message: '成长值不足' });
    }
    
    user.growthValue -= amount;
    
    const newLevel = user.calculateLevel();
    if (newLevel !== user.memberLevel) {
      user.memberLevel = newLevel;
    }
    
    await user.save();
    
    await GrowthRecord.create({
      userId: user._id,
      type: 'expense',
      amount,
      description,
      source
    });
    
    res.json({
      message: '成长值已扣除',
      growthValue: user.growthValue,
      memberLevel: user.memberLevel
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getLevelInfo = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    
    const levelConfig = {
      newbie: { name: '萌新会员', min: 0, max: 99, nextLevel: '白银会员', needGrowth: 100 - user.growthValue },
      silver: { name: '白银会员', min: 100, max: 499, nextLevel: '黄金会员', needGrowth: 500 - user.growthValue },
      gold: { name: '黄金会员', min: 500, max: 1999, nextLevel: '钻石会员', needGrowth: 2000 - user.growthValue },
      diamond: { name: '钻石会员', min: 2000, max: -1, nextLevel: '', needGrowth: 0 }
    };
    
    const currentLevel = levelConfig[user.memberLevel];
    
    const allLevels = Object.keys(levelConfig).map(key => ({
      key,
      ...levelConfig[key]
    }));
    
    res.json({
      currentLevel,
      allLevels,
      growthValue: user.growthValue,
      totalGrowthValue: user.totalGrowthValue
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

import Task from '../models/Task.js';
import User from '../models/User.js';
import GrowthRecord from '../models/GrowthRecord.js';

export const getTasks = async (req, res) => {
  try {
    const { type } = req.query;
    let query = { isActive: true };
    
    if (type && ['newbie', 'daily', 'weekly', 'monthly', 'premium'].includes(type)) {
      query.type = type;
    }
    
    const tasks = await Task.find(query).sort({ type: 1, reward: -1 });
    
    const user = await User.findById(req.user._id);
    
    const tasksWithProgress = tasks.map(task => {
      const completed = user.completedTasks.filter(t => t.startsWith(task._id.toString())).length;
      return {
        ...task._doc,
        completed,
        isCompleted: completed >= task.target
      };
    });
    
    res.json(tasksWithProgress);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getAllTasksForAdmin = async (req, res) => {
  try {
    const { page = 1, limit = 10, search, type, status } = req.query;
    
    let query = {};
    
    if (search) {
      query.name = { $regex: search, $options: 'i' };
    }
    
    if (type && ['newbie', 'daily', 'weekly', 'monthly', 'premium'].includes(type)) {
      query.type = type;
    }
    
    if (status === 'active') {
      query.isActive = true;
    } else if (status === 'inactive') {
      query.isActive = false;
    }
    
    const tasks = await Task.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    
    const total = await Task.countDocuments(query);
    
    res.json({
      tasks,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(total / limit)
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getTaskById = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    
    if (task) {
      res.json(task);
    } else {
      res.status(404).json({ message: '任务不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createTask = async (req, res) => {
  try {
    const task = await Task.create(req.body);
    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateTask = async (req, res) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    
    if (task) {
      res.json(task);
    } else {
      res.status(404).json({ message: '任务不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const deleteTask = async (req, res) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    
    if (task) {
      res.json({ message: '任务已删除' });
    } else {
      res.status(404).json({ message: '任务不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const completeTask = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    
    if (!task) {
      return res.status(404).json({ message: '任务不存在' });
    }
    
    const user = await User.findById(req.user._id);
    
    const taskKey = `${task._id}_${Date.now()}`;
    user.completedTasks.push(taskKey);
    user.growthValue += task.reward;
    user.totalGrowthValue += task.reward;
    
    const newLevel = user.calculateLevel();
    if (newLevel !== user.memberLevel) {
      user.memberLevel = newLevel;
    }
    
    await user.save();
    
    await GrowthRecord.create({
      userId: user._id,
      type: 'income',
      amount: task.reward,
      description: task.name,
      source: 'task'
    });
    
    res.json({
      message: '任务完成',
      growthValue: user.growthValue,
      memberLevel: user.memberLevel
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

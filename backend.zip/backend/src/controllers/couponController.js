import Coupon from '../models/Coupon.js';

export const getCoupons = async (req, res) => {
  try {
    const { type } = req.query;
    let query = { isActive: true };
    
    if (type && ['discount', 'full', 'gift', 'activity'].includes(type)) {
      query.type = type;
    }
    
    const coupons = await Coupon.find(query).sort({ createdAt: -1 });
    res.json(coupons);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getCouponById = async (req, res) => {
  try {
    const coupon = await Coupon.findById(req.params.id);
    
    if (coupon) {
      res.json(coupon);
    } else {
      res.status(404).json({ message: '优惠券不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createCoupon = async (req, res) => {
  try {
    const coupon = await Coupon.create(req.body);
    res.status(201).json(coupon);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateCoupon = async (req, res) => {
  try {
    const coupon = await Coupon.findByIdAndUpdate(req.params.id, req.body, { new: true });
    
    if (coupon) {
      res.json(coupon);
    } else {
      res.status(404).json({ message: '优惠券不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const deleteCoupon = async (req, res) => {
  try {
    const coupon = await Coupon.findByIdAndDelete(req.params.id);
    
    if (coupon) {
      res.json({ message: '优惠券已删除' });
    } else {
      res.status(404).json({ message: '优惠券不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

import User from '../models/User.js';
import jwt from 'jsonwebtoken';

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d'
  });
};

export const register = async (req, res) => {
  try {
    const { phone, password, nickname } = req.body;
    
    const userExists = await User.findOne({ phone });
    if (userExists) {
      return res.status(400).json({ message: '用户已存在' });
    }
    
    const user = await User.create({
      phone,
      password,
      nickname: nickname || `用户${phone.slice(-4)}`
    });
    
    res.status(201).json({
      _id: user._id,
      phone: user.phone,
      nickname: user.nickname,
      memberLevel: user.memberLevel,
      growthValue: user.growthValue,
      token: generateToken(user._id)
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const login = async (req, res) => {
  try {
    const { phone, password } = req.body;
    
    const user = await User.findOne({ phone });
    
    if (user && (await user.matchPassword(password))) {
      res.json({
        _id: user._id,
        phone: user.phone,
        nickname: user.nickname,
        memberLevel: user.memberLevel,
        growthValue: user.growthValue,
        token: generateToken(user._id)
      });
    } else {
      res.status(401).json({ message: '手机号或密码错误' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    
    if (user) {
      user.nickname = req.body.nickname || user.nickname;
      user.avatar = req.body.avatar || user.avatar;
      
      const updatedUser = await user.save();
      
      res.json({
        _id: updatedUser._id,
        phone: updatedUser.phone,
        nickname: updatedUser.nickname,
        avatar: updatedUser.avatar,
        memberLevel: updatedUser.memberLevel,
        growthValue: updatedUser.growthValue
      });
    } else {
      res.status(404).json({ message: '用户不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getUserStats = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    
    const levelInfo = {
      newbie: { name: '萌新会员', min: 0, max: 99, next: '白银会员', need: 100 - user.growthValue },
      silver: { name: '白银会员', min: 100, max: 499, next: '黄金会员', need: 500 - user.growthValue },
      gold: { name: '黄金会员', min: 500, max: 1999, next: '钻石会员', need: 2000 - user.growthValue },
      diamond: { name: '钻石会员', min: 2000, max: -1, next: '', need: 0 }
    };
    
    res.json({
      currentLevel: levelInfo[user.memberLevel],
      growthValue: user.growthValue,
      totalGrowthValue: user.totalGrowthValue,
      completedTasks: user.completedTasks.length
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
